package utils;

public enum Gender {
	Male, Female, Unknown
}
