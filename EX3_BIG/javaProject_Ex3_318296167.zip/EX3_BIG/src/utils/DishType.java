package utils;

public enum DishType {
	Starter, Main, Dessert
}
