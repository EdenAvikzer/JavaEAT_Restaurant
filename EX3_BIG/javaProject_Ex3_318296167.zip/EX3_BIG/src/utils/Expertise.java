package utils;

public enum Expertise {
	Italien, Mediterranean, American, French, Indian, Asian
}
