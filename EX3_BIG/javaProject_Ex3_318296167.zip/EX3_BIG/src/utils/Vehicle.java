package utils;

public enum Vehicle {
	Car, Motorcycle, Bicycle
}
