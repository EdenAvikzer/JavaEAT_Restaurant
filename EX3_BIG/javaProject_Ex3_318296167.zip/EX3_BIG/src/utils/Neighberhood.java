package utils;

public enum Neighberhood {
	Neve_Shanan, Kiriat_Haim, DownTown, Vardia, Bat_Galim, Merkaz_Karmel, Denya, Kiriat_Eliezer,
	Hadar, Romema, German_Colony, Vadi_Nisnas, Vadi_Saliv, Neot_Peres, Kababir, Neve_David,
	Karmelia, Halisa, French_Karmel, Ramat_Hanasi, Neve_Yosef, Ramat_Almogi
}
