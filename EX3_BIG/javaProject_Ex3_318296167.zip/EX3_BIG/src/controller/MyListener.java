package controller;

import model.Dish;

public interface MyListener {
	
	public void onClickListener(Dish dish);

}
